package com.example.vishal_patel_project1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    protected Button button1;
    private int returnedCode = 6;
    protected Button button2;
    private TextView validName;
    private boolean isValid; // if name is vaild
    private boolean buttonUsed;
    private String validName2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button10);// button 1
        button1.setOnClickListener(button1Listen);

        button2 = (Button) findViewById(R.id.button20);// button 2
        button2.setOnClickListener(button2Listen);
        validName = (TextView) findViewById(R.id.validName);
    }

    public View.OnClickListener button1Listen = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, nameValid.class);
            startActivityForResult(intent, returnedCode);
        }
    };

    public View.OnClickListener button2Listen = new View.OnClickListener() {
        @Override
        public void onClick(View v) {// if button 1 has been clicked we contuinoe to thiis
            Context ct = getApplicationContext();
            if (isValid) {// check to see if input was valid
                Intent intent3 = new Intent(ContactsContract.Intents.Insert.ACTION);
                intent3.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                intent3.putExtra(ContactsContract.Intents.Insert.NAME, validName2);
                startActivity(intent3);
            } else {
                String toastString = "invalid name: " + validName2;
                Toast.makeText(getApplicationContext(), toastString, Toast.LENGTH_SHORT).show();
            }

        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (returnedCode == requestCode) {
            if (data != null) { // check if data exists
                // set the text to a number
                validName.setText(data.getStringExtra("Name"));
            }
            if (resultCode == RESULT_OK) { // valid name

                isValid = true;
            } else if (resultCode == RESULT_CANCELED) { // invalid name
                isValid = false;
            }
        }
        validName2 = data.getStringExtra("Name");
        validName.setText(validName2);
    }
}