package com.example.vishal_patel_project1;

import androidx.appcompat.app.AppCompatActivity;import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent;
import android.content.Intent;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Pattern;

public class nameValid extends AppCompatActivity {
    private EditText nameTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.namevalid);
        nameTxt = (EditText) findViewById(R.id.enterName);
        nameTxt.setOnEditorActionListener(mEditorActionListener);
    }
    private TextView.OnEditorActionListener mEditorActionListener = new TextView.OnEditorActionListener() {// this is where we type in our name
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //^[\\p{L} .'-]+$  ^[a-zA-Z\\s]*$  [\a-zA-Z]+[a-zA-Z]+
                Intent Intent2 = new Intent();
                String name = v.getText().toString();
                //Intent Intent2 = new Intent(nameValid.this, MainActivity.class);
                Intent2.putExtra("name", name);
                boolean bl = Pattern.matches("[\\sa-zA-Z][a-zA-Z][a-zA-Z]+", name);// checks for a vaild name


                if(bl == true)// if vaild name return ture if not return cancles
                {
                    setResult(RESULT_OK,Intent2);
                }
                else{
                    setResult(RESULT_CANCELED, Intent2);
                }
                finish();
            return false;

        }
    };


}
